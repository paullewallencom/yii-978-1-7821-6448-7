<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 0.2b
 */

//
// Database "photogallery"
//

// photogallery.tbl_photo
return array(
  'IMG_1134'=>array('album_id'=>'1','filename'=>'IMG_1134.jpg','caption'=>'Pebbles through clear water','alt_text'=>'','tags'=>NULL,'sort_order'=>'1','created_dt'=>'2013-02-05 12:27:53','lastupdate_dt'=>'2013-02-05 12:27:53'),
  'IMG_1152'=>array('album_id'=>'1','filename'=>'IMG_1152.jpg','caption'=>'Going with the flow','alt_text'=>'','tags'=>NULL,'sort_order'=>'2','created_dt'=>'2013-02-05 12:25:27','lastupdate_dt'=>'2013-02-05 12:27:53'),
  'IMG_1289'=>array('album_id'=>'1','filename'=>'IMG_1289.jpg','caption'=>'Calm after the storm','alt_text'=>NULL,'tags'=>NULL,'sort_order'=>'3','created_dt'=>'2013-02-04 14:26:35','lastupdate_dt'=>'2013-02-05 12:27:53'),
  'IMG_1291'=>array('album_id'=>'1','filename'=>'IMG_1291.jpg','caption'=>'Peaceful evening on the beach','alt_text'=>NULL,'tags'=>NULL,'sort_order'=>'4','created_dt'=>'2013-02-05 11:28:47','lastupdate_dt'=>'2013-02-05 12:27:53'),
  'IMG_1331'=>array('album_id'=>'1','filename'=>'IMG_1331.jpg','caption'=>'Sand Waves','alt_text'=>NULL,'tags'=>NULL,'sort_order'=>'5','created_dt'=>'2013-02-05 10:15:55','lastupdate_dt'=>'2013-02-05 12:27:53'),
  'IMG_9609'=>array('album_id'=>'1','filename'=>'IMG_9609.jpg','caption'=>'Rippled sand','alt_text'=>'','tags'=>NULL,'sort_order'=>'6','created_dt'=>'2013-01-30 01:29:05','lastupdate_dt'=>'2013-02-05 12:27:53')
);
