<h1>Welcome to Photo Gallery</h1>
<p>Thank you for registering with PhotoGallery.
    You should now be logged in and able to create your own Albums and upload Photos</p>
<p>Have Fun!</p>