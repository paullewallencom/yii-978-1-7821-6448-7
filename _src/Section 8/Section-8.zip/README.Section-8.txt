/**
Copyright: Packt Publishing
Create By: Chris Backhouse - SudWebDesign
Created Date: 20.04.2013
Description:  This README file is to accompany code downloads for Section 8 of the 
Video Series "Beginning Yii" from Packt Publishing.
**/

This zip file contains the all the files modified in Section 8

To copy the latest PhotoGal theme, copy the www/thems/PhotoGal from this zip file and 
overwrite those in your www directory

You will also find a simplified User registration system in the User controller and Views...

