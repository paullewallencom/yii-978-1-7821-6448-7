Extra lightweight errors/exceptions/debugs handler for Google Chrome extension PHP Console

Google Chrome extension "PHP Console" installation:
https://chrome.google.com/extensions/detail/nfhmhhlpfleoednkpnnnkolmclajemef

SVN/trunk:
https://php-console.googlecode.com/svn/trunk/PhpConsole

Project site:
http://code.google.com/p/php-console

Project updates by RSS:
http://code.google.com/feeds/p/php-console/updates/basic

Contact to developer (freelancer, looking for interesting web-projects):
http://linkedin.com/in/barbushin