/**
Copyright: Packt Publishing
Create By: Chris Backhouse - SudWebDesign
Created Date: 04.03.2013
Description:  This README file is to accompany code downloads for Section 3 of the 
Video Series "Beginning Yii" from Packt Publishing.
**/

This zip file is for use at the beginning of Section 4 and contains all the code
up to the end of Section 3.

Copy all these files into your project directory and over-write your entire Project.

But don't worry ...

The Protected/Config/main.php has been renamed so as not to over-write your 
configuration file.  If you wish to use this copy to run a fresh install, 
then you will need to rename Protected/Config/main-original.php to main.php

Also, in the www directory you would need to rename index-original.php to index.php
